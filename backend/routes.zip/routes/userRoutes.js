const express = require('express');
const router = express.Router();
const User = require('../models/User');

// 1. POST: Sync User (Login/Signup)
router.post('/sync', async (req, res) => {
  const { uid, email, name, photoURL } = req.body;
  try {
    let user = await User.findOne({ uid });
    if (!user) {
      user = new User({ 
        uid, email, name, profilePicture: photoURL || '',
        // Default data for new users
        stats: { profileComplete: 15, coursesStarted: 0, badgesEarned: 0, totalPoints: 0 },
        recentActivities: [{ text: "Joined EduCareer", points: "+10", type: "badge" }],
        upcomingTasks: [{ title: "Complete Profile", deadline: "Today", priority: "High" }]
      });
      await user.save();
      return res.status(201).json(user);
    }
    return res.status(200).json(user);
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
});

// 2. GET: Fetch User Data (Fixes the 404 Error on Dashboard)
router.get('/:uid', async (req, res) => {
  try {
    const user = await User.findOne({ uid: req.params.uid });
    if (!user) return res.status(404).json({ message: "User not found" });
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: "Server Error" });
  }
});

// 3. PUT: Update Profile (Used by Profile Page)
router.put('/:uid', async (req, res) => {
  try {
    const { name, skills } = req.body;
    const updatedUser = await User.findOneAndUpdate(
      { uid: req.params.uid },
      { $set: { name, skills } },
      { new: true }
    );
    res.json(updatedUser);
  } catch (error) {
    res.status(500).json({ message: "Server Error" });
  }
});

module.exports = router;