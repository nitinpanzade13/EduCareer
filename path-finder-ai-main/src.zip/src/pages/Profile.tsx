import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea"; // Ensure you have this or use standard textarea
import { 
  User, Mail, Calendar, MapPin, Save, ArrowLeft, 
  Camera, Briefcase, GraduationCap, Award, Loader2, Plus, X
} from "lucide-react";
import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

interface UserProfile {
  name: string;
  email: string;
  uid: string;
  skills: string[];
  stats: {
    profileComplete: number;
    badgesEarned: number;
  };
  createdAt: string;
}

export default function Profile() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [newSkill, setNewSkill] = useState("");
  
  // Form State
  const [name, setName] = useState("");
  const [skills, setSkills] = useState<string[]>([]);

  const navigate = useNavigate();
  const { toast } = useToast();

  // 1. Fetch User Data
  useEffect(() => {
    const fetchUser = async () => {
      const localData = localStorage.getItem("educareer_user");
      if (!localData) return navigate("/auth");
      
      const { uid } = JSON.parse(localData);
      
      try {
        const res = await fetch(`http://localhost:5000/api/users/${uid}`);
        if (res.ok) {
          const data = await res.json();
          setUser(data);
          setName(data.name);
          setSkills(data.skills || []);
        }
      } catch (error) {
        console.error("Failed to load profile", error);
      } finally {
        setLoading(false);
      }
    };
    fetchUser();
  }, [navigate]);

  // 2. Save Changes
  const handleSave = async () => {
    if (!user) return;
    setSaving(true);

    try {
      const res = await fetch(`http://localhost:5000/api/users/${user.uid}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, skills }),
      });

      if (!res.ok) throw new Error("Failed to update");

      // Update local storage name too so the sidebar updates on refresh
      const localData = JSON.parse(localStorage.getItem("educareer_user") || "{}");
      localStorage.setItem("educareer_user", JSON.stringify({ ...localData, name }));

      toast({ title: "Profile Updated", description: "Your changes have been saved." });
    } catch (error) {
      toast({ title: "Error", description: "Could not save changes.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const addSkill = () => {
    if (newSkill.trim() && !skills.includes(newSkill.trim())) {
      setSkills([...skills, newSkill.trim()]);
      setNewSkill("");
    }
  };

  const removeSkill = (skillToRemove: string) => {
    setSkills(skills.filter(s => s !== skillToRemove));
  };

  if (loading) return <div className="flex h-screen items-center justify-center"><Loader2 className="animate-spin text-primary" /></div>;
  if (!user) return null;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 flex items-center gap-4">
          <Link to="/dashboard" className="text-muted-foreground hover:text-primary transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-xl font-bold">My Profile</h1>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column: Identity Card */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-card border border-border rounded-2xl p-6 text-center shadow-card relative overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-24 gradient-hero" />
              <div className="relative mt-8 mb-4">
                <div className="w-24 h-24 mx-auto rounded-full bg-background p-1 border-4 border-background shadow-lg">
                  <div className="w-full h-full rounded-full gradient-primary flex items-center justify-center text-3xl font-bold text-white">
                    {name.charAt(0)}
                  </div>
                </div>
                <button className="absolute bottom-0 right-1/2 translate-x-10 translate-y-2 bg-primary text-white p-2 rounded-full hover:bg-primary/90 shadow-md">
                  <Camera className="w-4 h-4" />
                </button>
              </div>
              
              <h2 className="text-2xl font-bold text-foreground">{name}</h2>
              <p className="text-muted-foreground mb-6">{user.email}</p>

              <div className="grid grid-cols-2 gap-4 border-t border-border pt-6">
                <div className="text-center">
                  <p className="text-2xl font-bold text-primary">{user.stats?.badgesEarned || 0}</p>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider">Badges</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-green-500">{user.stats?.profileComplete || 0}%</p>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider">Complete</p>
                </div>
              </div>
            </div>

            <div className="bg-card border border-border rounded-2xl p-6 space-y-4">
              <h3 className="font-semibold flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-500" />
                Achievements
              </h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/50">
                  <div className="w-8 h-8 rounded-lg bg-green-100 flex items-center justify-center text-green-600">
                    <Briefcase className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Early Adopter</p>
                    <p className="text-xs text-muted-foreground">Joined 2024</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Edit Forms */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-card border border-border rounded-2xl p-6">
              <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                <User className="w-5 h-5 text-primary" />
                Personal Information
              </h3>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Full Name</Label>
                  <Input 
                    value={name} 
                    onChange={(e) => setName(e.target.value)} 
                    placeholder="Your Name" 
                  />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input value={user.email} disabled className="bg-muted opacity-70" />
                  <p className="text-xs text-muted-foreground">Email cannot be changed</p>
                </div>
                <div className="space-y-2">
                  <Label>Join Date</Label>
                  <div className="flex items-center gap-2 px-3 py-2 border border-border rounded-md bg-muted/30 text-muted-foreground">
                    <Calendar className="w-4 h-4" />
                    {new Date(user.createdAt).toLocaleDateString()}
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-card border border-border rounded-2xl p-6">
              <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-primary" />
                Skills & Expertise
              </h3>
              
              <div className="space-y-4">
                <div className="flex gap-2">
                  <Input 
                    placeholder="Add a skill (e.g., Python, Leadership)"
                    value={newSkill}
                    onChange={(e) => setNewSkill(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && addSkill()}
                  />
                  <Button onClick={addSkill} variant="secondary">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>

                <div className="flex flex-wrap gap-2 min-h-[50px] p-4 border border-dashed border-border rounded-xl">
                  {skills.length === 0 && (
                    <p className="text-sm text-muted-foreground w-full text-center py-2">No skills added yet.</p>
                  )}
                  {skills.map((skill) => (
                    <span key={skill} className="inline-flex items-center gap-1 bg-primary/10 text-primary px-3 py-1 rounded-full text-sm">
                      {skill}
                      <button onClick={() => removeSkill(skill)} className="hover:text-red-500 ml-1">
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end">
              <Button size="lg" onClick={handleSave} disabled={saving} className="shadow-glow">
                {saving ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Save Changes
                  </>
                )}
              </Button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}