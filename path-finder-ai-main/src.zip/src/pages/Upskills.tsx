import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { 
  BookOpen, ArrowLeft, Search, Play, Clock, Users, Star,
  Trophy, Target, Zap, Award, CheckCircle, Lock, ChevronRight,
  Brain, Code, BarChart, Briefcase, Filter, TrendingUp,
  Loader2, Timer, Terminal, X, RotateCcw, Video, Mic, Camera
} from "lucide-react";
import { Link } from "react-router-dom";
import { useState, useMemo, useEffect, useRef } from "react";
import { useToast } from "@/hooks/use-toast";

// --- EXPANDED MOCK DATA ---
const categories = [
  { id: "all", name: "All Courses", icon: BookOpen },
  { id: "programming", name: "Programming", icon: Code },
  { id: "data", name: "Data Science", icon: BarChart },
  { id: "aptitude", name: "Aptitude", icon: Brain },
  { id: "career", name: "Career Skills", icon: Briefcase },
];

const courses = [
  { id: 1, title: "Complete Python Programming", category: "programming", level: "Beginner", duration: "12 hours", lessons: 45, enrolled: "15.2K", rating: 4.8, progress: 65, image: "https://images.unsplash.com/photo-1526379095098-d400fd0bf935?w=300", instructor: "Dr. Priya Sharma" },
  { id: 2, title: "Data Structures & Algorithms", category: "programming", level: "Intermediate", duration: "24 hours", lessons: 80, enrolled: "22.5K", rating: 4.9, progress: 30, image: "https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=300", instructor: "Prof. Amit Kumar" },
  { id: 3, title: "Machine Learning Fundamentals", category: "data", level: "Intermediate", duration: "18 hours", lessons: 60, enrolled: "18.7K", rating: 4.7, progress: 0, image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=300", instructor: "Dr. Neha Gupta" },
  { id: 4, title: "React JS Masterclass", category: "programming", level: "Advanced", duration: "20 hours", lessons: 55, enrolled: "10.1K", rating: 4.6, progress: 0, image: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=300", instructor: "Sarah Jenkins" },
];

// --- 🧠 EXPANDED QUESTION BANK ---
const questionBank = {
  python: [
    { id: 1, type: "mcq", question: "What is the correct extension for a Python file?", options: [".pyt", ".pyth", ".py", ".pt"], correct: 2 },
    { id: 2, type: "mcq", question: "Which of these is NOT a core data type in standard Python?", options: ["List", "Dictionary", "Class", "Tuple"], correct: 2 },
    { id: 3, type: "code", question: "Write a function `sum_two` that takes two numbers `a` and `b` and returns their sum.", starterCode: "def sum_two(a, b):\n    # Write your code here\n    pass", testCase: "sum_two(3, 5) == 8" },
  ],
  react: [
    { id: 1, type: "mcq", question: "Which hook is used to manage state in a functional component?", options: ["useEffect", "useState", "useContext", "useReducer"], correct: 1 },
    { id: 2, type: "mcq", question: "What is the virtual DOM?", options: ["A direct copy of the HTML DOM", "A lightweight copy of the DOM", "A browser extension", "None of the above"], correct: 1 },
    { id: 3, type: "descriptive", question: "Explain the difference between Props and State.", placeholder: "Type your answer..." },
  ],
  aptitude: [
    { id: 1, type: "mcq", question: "Find the missing number: 2, 6, 12, 20, ?", options: ["30", "32", "42", "28"], correct: 0 },
    { id: 2, type: "mcq", question: "If a shirt costs $20 after a 20% discount, what was the original price?", options: ["$25", "$24", "$30", "$22"], correct: 0 },
  ]
};

const interviewQuestionSets = {
  hr: [
    "Tell me about a time you faced a significant challenge.",
    "Where do you see yourself in 5 years?",
    "Why should we hire you over other candidates?"
  ],
  frontend: [
    "Explain the concept of closures in JavaScript.",
    "How do you optimize a React application for performance?",
    "Describe the difference between localStorage and sessionStorage."
  ],
  backend: [
    "Explain the difference between SQL and NoSQL databases.",
    "How do you handle authentication in a REST API?",
    "What is the purpose of a reverse proxy?"
  ]
};

const quizzes = [
  { id: "python", title: "Python Basics", questions: 3, duration: "10 min", difficulty: "Easy", category: "Programming" },
  { id: "react", title: "React JS Advanced", questions: 3, duration: "15 min", difficulty: "Hard", category: "Programming" },
  { id: "aptitude", title: "Logical Reasoning", questions: 2, duration: "10 min", difficulty: "Medium", category: "Aptitude" },
];

const achievements = [
  { icon: Trophy, title: "Quiz Master", description: "Complete 10 quizzes", progress: 70, unlocked: false },
  { icon: Target, title: "Sharp Shooter", description: "Score 100% in any quiz", progress: 100, unlocked: true },
  { icon: Zap, title: "Fast Learner", description: "Finish a course in 1 day", progress: 30, unlocked: false },
];

// --- WEB SPEECH API SETUP ---
const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

export default function Upskills() {
  const [activeTab, setActiveTab] = useState<"courses" | "quizzes" | "achievements" | "interview">("courses");
  const [activeCategory, setActiveCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();

  // --- TEST MODE STATE ---
  const [testMode, setTestMode] = useState(false);
  const [activeQuizId, setActiveQuizId] = useState<string | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, any>>({});
  const [timeLeft, setTimeLeft] = useState(900);
  const [codeOutput, setCodeOutput] = useState("");
  const [isTestRunning, setIsTestRunning] = useState(false);
  const [testResult, setTestResult] = useState<{score: number, accuracy: number} | null>(null);

  // --- 🎥 INTERVIEW MODE STATE ---
  const [interviewMode, setInterviewMode] = useState(false);
  const [interviewStep, setInterviewStep] = useState<"setup" | "recording" | "processing" | "result">("setup");
  const [interviewCategory, setInterviewCategory] = useState<"hr" | "frontend" | "backend">("hr");
  const [currentInterviewQ, setCurrentInterviewQ] = useState(0);
  const [recordingTime, setRecordingTime] = useState(0);
  
  // Real-time Transcription State
  const [transcript, setTranscript] = useState(""); 
  const recognitionRef = useRef<any>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [analysisResult, setAnalysisResult] = useState<any>(null);

  // --- FILTER LOGIC ---
  const filteredCourses = useMemo(() => {
    return courses.filter(course => 
      (activeCategory === "all" || course.category === activeCategory) &&
      course.title.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [activeCategory, searchQuery]);

  // --- TIMERS ---
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isTestRunning && timeLeft > 0) {
      timer = setInterval(() => setTimeLeft((prev) => prev - 1), 1000);
    } else if (timeLeft === 0 && isTestRunning) {
      finishTest();
    }
    return () => clearInterval(timer);
  }, [isTestRunning, timeLeft]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (interviewStep === "recording") {
      interval = setInterval(() => setRecordingTime(prev => prev + 1), 1000);
    }
    return () => clearInterval(interval);
  }, [interviewStep]);

  // --- TEST HANDLERS ---
  const startTest = (quizId: string) => {
    setActiveQuizId(quizId);
    setTestMode(true);
    setIsTestRunning(true);
    setTimeLeft(600); // Default 10 mins
    setCurrentQuestionIndex(0);
    setAnswers({});
    setTestResult(null);
    setCodeOutput("");
  };

  const handleAnswer = (value: any) => {
    setAnswers(prev => ({ ...prev, [currentQuestionIndex]: value }));
  };

  const runCode = () => {
    setCodeOutput("Running...");
    setTimeout(() => {
      // Very basic mock check
      const code = answers[currentQuestionIndex] || "";
      if (code.includes("return a + b") || code.includes("return a+b")) {
        setCodeOutput(`> Test Case Passed! ✅\n> Input: (3, 5)\n> Output: 8`);
      } else {
        setCodeOutput(`> Test Case Failed ❌\n> Expected: 8\n> Hint: Ensure you return the sum.`);
      }
    }, 1000);
  };

  const finishTest = () => {
    setIsTestRunning(false);
    const currentQuestions = questionBank[activeQuizId as keyof typeof questionBank] || [];
    let correctCount = 0;
    
    currentQuestions.forEach((q, idx) => {
      if (q.type === 'mcq' && answers[idx] === q.correct) correctCount++;
      else if (q.type === 'code' && (answers[idx] || "").includes("return")) correctCount++; // Mock check
      else if (q.type === 'descriptive' && (answers[idx] || "").length > 5) correctCount++; // Mock check
    });

    const score = (correctCount / currentQuestions.length) * 100;
    setTestResult({ score, accuracy: score });
  };

  // --- 🎥 INTERVIEW HANDLERS ---
  const startInterviewSetup = async () => {
    setInterviewMode(true);
    setInterviewStep("setup");
    setTranscript(""); 
    
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      setStream(mediaStream);
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
        }
      }, 100);
    } catch (err) {
      console.error("Camera error:", err);
      toast({ title: "Camera Error", description: "Could not access camera/mic.", variant: "destructive" });
    }
  };

  const stopInterview = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setInterviewMode(false);
    setInterviewStep("setup");
  };

  const startRecording = () => {
    if (!stream) return;
    setInterviewStep("recording");
    setRecordingTime(0);
    setTranscript("");

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        let currentTranscript = "";
        for (let i = event.resultIndex; i < event.results.length; i++) {
          currentTranscript += event.results[i][0].transcript;
        }
        setTranscript(currentTranscript);
      };

      recognition.start();
      recognitionRef.current = recognition;
    } else {
      toast({ title: "Browser Not Supported", description: "Use Chrome for speech recognition.", variant: "destructive" });
    }
  };

  const finishRecording = async () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setInterviewStep("processing");

    // Simulate Network Call or Real Call
    try {
      const questions = interviewQuestionSets[interviewCategory];
      const currentQ = questions[currentInterviewQ];
      const finalAnswer = transcript.length > 5 ? transcript : "I answered this question by explaining my process step by step."; 
      
      // MOCK BACKEND RESPONSE FOR DEMO (Replace fetch with this if no backend)
      setTimeout(() => {
        setAnalysisResult({ 
          transcription: finalAnswer,
          rating: Math.floor(Math.random() * 3) + 7, // 7-9
          sentiment: "Confident",
          feedback: "Good structure. Try to include more specific metrics next time."
        });
        setInterviewStep("result");
      }, 2000);

      // REAL BACKEND CALL (Uncomment when backend is ready)
      /*
      const response = await fetch('http://localhost:5000/api/interview/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: currentQ, answer: finalAnswer })
      });
      const data = await response.json();
      setAnalysisResult({ ...data, transcription: finalAnswer });
      setInterviewStep("result");
      */
      
    } catch (error) {
      console.error("Analysis failed", error);
      setInterviewStep("result");
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  // ------------------------------------------
  // 🎥 INTERVIEW RENDER
  // ------------------------------------------
  if (interviewMode) {
    const questions = interviewQuestionSets[interviewCategory];
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-4xl relative">
          <div className="absolute top-4 left-4 z-10">
            <div className="bg-black/50 backdrop-blur-md text-white px-4 py-2 rounded-full flex items-center gap-2">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" /> 
              AI Interviewer ({interviewCategory.toUpperCase()})
            </div>
          </div>
          <Button variant="secondary" size="icon" className="absolute top-4 right-4 z-10 rounded-full" onClick={stopInterview}>
            <X className="w-5 h-5" />
          </Button>

          <div className="relative aspect-video bg-zinc-900 rounded-3xl overflow-hidden border border-zinc-800 shadow-2xl">
            {interviewStep !== "processing" && interviewStep !== "result" && (
              <>
                <video ref={videoRef} autoPlay muted playsInline className="w-full h-full object-cover mirror-mode" />
                {transcript && (
                  <div className="absolute bottom-24 left-0 right-0 text-center px-8">
                    <span className="bg-black/60 text-white px-4 py-2 rounded-xl text-lg font-medium backdrop-blur-sm">"{transcript}"</span>
                  </div>
                )}
              </>
            )}

            {interviewStep === "processing" && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-zinc-900 text-white">
                <Loader2 className="w-12 h-12 animate-spin text-primary mb-4" />
                <h3 className="text-xl font-medium">Gemini AI is analyzing...</h3>
              </div>
            )}

            {interviewStep === "result" && analysisResult && (
              <div className="absolute inset-0 bg-zinc-900 p-8 overflow-y-auto">
                <div className="max-w-2xl mx-auto text-left">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 bg-green-500/20 rounded-full flex items-center justify-center"><CheckCircle className="w-6 h-6 text-green-500" /></div>
                    <div><h2 className="text-2xl font-bold text-white">Feedback Ready</h2><p className="text-zinc-400">Question: {questions[currentInterviewQ]}</p></div>
                  </div>
                  <div className="space-y-6">
                    <div className="bg-zinc-800/50 p-6 rounded-xl border border-zinc-700">
                      <h4 className="text-sm font-bold text-zinc-400 uppercase mb-2">You Said:</h4>
                      <p className="text-zinc-100 leading-relaxed italic">"{analysisResult.transcription}"</p>
                    </div>
                    <div className="bg-zinc-800/50 p-6 rounded-xl border border-zinc-700">
                      <h4 className="text-sm font-bold text-zinc-400 uppercase mb-2">AI Feedback</h4>
                      <p className="text-zinc-100 leading-relaxed">{analysisResult.feedback}</p>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-zinc-800/50 p-4 rounded-xl border border-zinc-700 text-center"><p className="text-zinc-400 text-sm mb-1">Rating</p><p className="text-green-400 font-bold text-2xl">{analysisResult.rating}/10</p></div>
                      <div className="bg-zinc-800/50 p-4 rounded-xl border border-zinc-700 text-center"><p className="text-zinc-400 text-sm mb-1">Sentiment</p><p className="text-blue-400 font-bold text-2xl">{analysisResult.sentiment}</p></div>
                    </div>
                    <Button className="w-full" size="lg" onClick={() => { setInterviewStep("setup"); setCurrentInterviewQ(prev => (prev + 1) % questions.length) }}>Next Question <ChevronRight className="w-4 h-4 ml-2" /></Button>
                  </div>
                </div>
              </div>
            )}

            {(interviewStep === "setup" || interviewStep === "recording") && (
              <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-black/80 to-transparent flex flex-col items-center">
                <h3 className="text-xl md:text-2xl font-bold text-white text-center mb-6 max-w-2xl leading-tight">"{questions[currentInterviewQ]}"</h3>
                {interviewStep === "setup" ? (
                  <Button size="lg" className="rounded-full px-8 h-14 text-lg bg-red-600 hover:bg-red-700 text-white border-0" onClick={startRecording}><Video className="w-5 h-5 mr-2" /> Start Answer</Button>
                ) : (
                  <div className="flex items-center gap-4">
                    <div className="font-mono text-red-400 bg-red-500/10 px-4 py-2 rounded-lg animate-pulse">{formatTime(recordingTime)} / 02:00</div>
                    <Button size="lg" variant="secondary" className="rounded-full px-8 h-14 text-lg" onClick={finishRecording}><CheckCircle className="w-5 h-5 mr-2" /> Submit Answer</Button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ------------------------------------------
  // 📝 TEST MODE RENDER
  // ------------------------------------------
  if (testMode && activeQuizId) {
    if (testResult) {
      return (
        <div className="min-h-screen bg-background flex items-center justify-center p-4">
          <div className="bg-card w-full max-w-lg rounded-3xl border border-border p-8 text-center shadow-2xl animate-in zoom-in-95">
            <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6"><Trophy className="w-12 h-12 text-primary" /></div>
            <h2 className="text-3xl font-bold text-foreground mb-2">Test Complete!</h2>
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="p-4 rounded-2xl bg-muted/50 border border-border"><p className="text-sm text-muted-foreground mb-1">Total Score</p><p className="text-3xl font-bold text-foreground">{testResult.score.toFixed(0)}%</p></div>
              <div className="p-4 rounded-2xl bg-muted/50 border border-border"><p className="text-sm text-muted-foreground mb-1">Accuracy</p><p className={`text-3xl font-bold ${testResult.accuracy > 70 ? "text-green-500" : "text-amber-500"}`}>{testResult.accuracy > 70 ? "High" : "Average"}</p></div>
            </div>
            <div className="flex gap-3"><Button variant="outline" className="flex-1" onClick={() => setTestMode(false)}>Dashboard</Button><Button variant="hero" className="flex-1" onClick={() => startTest(activeQuizId)}><RotateCcw className="w-4 h-4 mr-2" /> Retake</Button></div>
          </div>
        </div>
      );
    }

    const currentQuestions = questionBank[activeQuizId as keyof typeof questionBank] || [];
    const question = currentQuestions[currentQuestionIndex];

    return (
      <div className="min-h-screen bg-background flex flex-col">
        <header className="bg-card border-b border-border sticky top-0 z-50 p-4 flex justify-between items-center">
          <div className="flex items-center gap-3"><Brain className="text-primary"/> <span className="font-bold capitalize">{activeQuizId} Quiz</span></div>
          <div className="flex items-center gap-4"><span className="font-mono bg-muted px-3 py-1 rounded">{formatTime(timeLeft)}</span> <Button variant="ghost" size="icon" onClick={() => setTestMode(false)}><X/></Button></div>
        </header>
        <div className="flex-1 container mx-auto p-4 md:p-8 max-w-4xl">
          <div className="bg-card border border-border rounded-2xl p-6">
            <h2 className="text-xl font-bold mb-6">{question?.question}</h2>
            {question?.type === "mcq" && <div className="grid gap-3">{question.options?.map((opt, idx) => (<button key={idx} onClick={() => handleAnswer(idx)} className={`text-left p-4 rounded-xl border-2 transition-all ${answers[currentQuestionIndex] === idx ? "border-primary bg-primary/5" : "border-border"}`}>{opt}</button>))}</div>}
            {question?.type === "descriptive" && <Textarea placeholder={question.placeholder} className="min-h-[200px]" value={answers[currentQuestionIndex] || ""} onChange={(e) => handleAnswer(e.target.value)} />}
            {question?.type === "code" && <div className="space-y-4"><div className="bg-slate-900 rounded-xl overflow-hidden border border-slate-700"><div className="bg-slate-800 px-4 py-2 text-xs text-slate-400">main.py</div><textarea className="w-full h-[300px] bg-slate-950 text-slate-50 font-mono p-4 resize-none focus:outline-none" value={answers[currentQuestionIndex] || question.starterCode} onChange={(e) => handleAnswer(e.target.value)} spellCheck={false} /></div><Button onClick={runCode} className="bg-green-600 hover:bg-green-700 text-white"><Play className="w-4 h-4 mr-2" /> Run Code</Button>{codeOutput && <div className="bg-slate-900 rounded-xl p-4 text-sm text-green-400 font-mono whitespace-pre-wrap">{codeOutput}</div>}</div>}
          </div>
        </div>
        <footer className="bg-card border-t border-border p-4 sticky bottom-0 flex justify-between container mx-auto max-w-4xl">
          <Button variant="outline" onClick={() => setCurrentQuestionIndex(prev => Math.max(0, prev - 1))} disabled={currentQuestionIndex === 0}>Previous</Button>
          {currentQuestionIndex === currentQuestions.length - 1 ? <Button onClick={finishTest}>Submit</Button> : <Button onClick={() => setCurrentQuestionIndex(prev => prev + 1)}>Next</Button>}
        </footer>
      </div>
    );
  }

  // --- MAIN DASHBOARD RENDER ---
  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="bg-card border-b border-border sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4"><Link to="/dashboard" className="flex items-center gap-2 text-muted-foreground hover:text-primary"><ArrowLeft className="w-5 h-5" /> Back</Link><span className="text-xl font-bold hidden md:block">Upskills & EasyPrep</span></div>
          <div className="flex items-center gap-2 bg-amber-100 text-amber-700 px-3 py-1.5 rounded-full"><Star className="w-4 h-4 fill-amber-500" /><span className="font-bold">12,500</span> pts</div>
        </div>
      </header>

      <div className="border-b border-border sticky top-[73px] bg-background/95 backdrop-blur z-30">
        <div className="container mx-auto px-4">
          <div className="flex gap-8 overflow-x-auto">
            {[{ id: "courses", label: "Courses", icon: BookOpen }, { id: "quizzes", label: "Tests & Quizzes", icon: Brain }, { id: "interview", label: "AI Interview", icon: Video }, { id: "achievements", label: "Achievements", icon: Trophy }].map((tab) => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id as any)} className={`flex items-center gap-2 py-4 border-b-2 transition-colors whitespace-nowrap font-medium ${activeTab === tab.id ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}><tab.icon className="w-4 h-4" /> {tab.label}</button>
            ))}
          </div>
        </div>
      </div>

      <section className="py-8">
        <div className="container mx-auto px-4">
          {activeTab === "courses" && (
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
              <div className="lg:col-span-1">
                <div className="sticky top-40 space-y-6">
                  <div className="relative"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" /><Input placeholder="Search..." className="pl-10" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} /></div>
                  <div className="bg-card rounded-xl border border-border p-4 shadow-sm"><h3 className="font-bold mb-3">Categories</h3><div className="space-y-1">{categories.map(c => <button key={c.id} onClick={() => setActiveCategory(c.id)} className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg ${activeCategory === c.id ? "bg-primary/10 text-primary" : "hover:bg-muted"}`}><c.icon className="w-5 h-5"/>{c.name}</button>)}</div></div>
                </div>
              </div>
              <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredCourses.map(course => (
                  <div key={course.id} className="bg-card rounded-2xl border border-border overflow-hidden hover:shadow-lg transition-all group flex flex-col h-full">
                    <div className="aspect-video relative"><img src={course.image} className="w-full h-full object-cover" /></div>
                    <div className="p-5 flex-1 flex flex-col"><h3 className="font-bold mb-1">{course.title}</h3><p className="text-xs text-muted-foreground mb-4">{course.instructor}</p><Button variant="hero" className="mt-auto w-full">Start Learning</Button></div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === "quizzes" && (
            <div className="max-w-5xl mx-auto">
              <h2 className="text-2xl font-bold mb-6">Skill Assessments</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {quizzes.map((quiz) => (
                  <div key={quiz.id} className="bg-card rounded-xl border border-border p-6 hover:border-primary/50 transition-all shadow-sm flex flex-col">
                    <div className="flex-1">
                      <div className="flex justify-between items-start mb-4">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${quiz.difficulty === 'Easy' ? 'bg-green-100 text-green-700' : quiz.difficulty === 'Medium' ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'}`}>{quiz.difficulty}</span>
                        <span className="text-xs text-muted-foreground">{quiz.category}</span>
                      </div>
                      <h3 className="font-bold text-lg text-foreground mb-2">{quiz.title}</h3>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground mb-6">
                        <span className="flex items-center gap-1"><Brain className="w-4 h-4" /> {quiz.questions} Qs</span>
                        <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {quiz.duration}</span>
                      </div>
                    </div>
                    <Button variant="hero" onClick={() => startTest(quiz.id)}>Start Quiz</Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === "interview" && (
            <div className="max-w-5xl mx-auto text-center">
              <div className="bg-gradient-to-br from-indigo-500/10 to-purple-500/10 rounded-3xl p-8 border border-indigo-500/20 mb-8">
                <h2 className="text-3xl font-bold mb-4">Select Interview Type</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                  <button onClick={() => setInterviewCategory("hr")} className={`p-6 rounded-xl border-2 transition-all ${interviewCategory === "hr" ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"}`}><Users className="w-8 h-8 mx-auto mb-2 text-primary"/><h3 className="font-bold">HR / Behavioral</h3></button>
                  <button onClick={() => setInterviewCategory("frontend")} className={`p-6 rounded-xl border-2 transition-all ${interviewCategory === "frontend" ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"}`}><Code className="w-8 h-8 mx-auto mb-2 text-blue-500"/><h3 className="font-bold">Frontend Dev</h3></button>
                  <button onClick={() => setInterviewCategory("backend")} className={`p-6 rounded-xl border-2 transition-all ${interviewCategory === "backend" ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"}`}><Terminal className="w-8 h-8 mx-auto mb-2 text-green-500"/><h3 className="font-bold">Backend Dev</h3></button>
                </div>
                <Button size="lg" variant="hero" className="px-10 h-12 text-lg shadow-lg" onClick={startInterviewSetup}>Start Interview Session</Button>
              </div>
            </div>
          )}

          {activeTab === "achievements" && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
              {achievements.map((a, i) => (
                <div key={i} className={`bg-card rounded-xl border p-6 flex gap-4 ${a.unlocked ? "border-primary/50 bg-primary/5" : "opacity-75"}`}>
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${a.unlocked ? "bg-primary text-white" : "bg-muted"}`}>{a.unlocked ? <a.icon/> : <Lock/>}</div>
                  <div><h3 className="font-bold">{a.title}</h3><p className="text-sm text-muted-foreground">{a.description}</p></div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}