import axios from 'axios';

const API_URL = 'http://localhost:5000/api/ai';

// --- 1. Aggressive Text Cleaner ---
const cleanResumeText = (text) => {
  return text
    .replace(/\r\n/g, "\n")
    .replace(/\t/g, " ")
    .replace(/([a-z])([A-Z])/g, '$1 $2') // Fix "PuneCGPA"
    .replace(/([a-zA-Z])(\d)/g, '$1 $2') // Fix "Khamgaon86"
    .replace(/^(SUMMARY|RESUME|CURRICULUM VITAE|PROFILE)$/im, "")
    .replace(/\n/g, " | ")
    .replace(/\s+/g, " ")
    .trim();
};

// --- 2. JSON Extractor ---
const extractJsonFromText = (text) => {
  try {
    let clean = text.replace(/```json/g, '').replace(/```/g, '');
    const firstBrace = clean.indexOf('{');
    const lastBrace = clean.lastIndexOf('}');
    if (firstBrace !== -1 && lastBrace !== -1) {
      clean = clean.substring(firstBrace, lastBrace + 1);
    }
    return JSON.parse(clean);
  } catch (e) {
    return null;
  }
};

// --- 3. Manual Fallback ---
const manualFallbackParser = (text) => {
  console.warn("⚠️ AI Failed. Using Regex Fallback.");
  const emailMatch = text.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/);
  const phoneMatch = text.match(/(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/);
  const linkedinMatch = text.match(/linkedin\.com\/in\/[a-zA-Z0-9-]+/);
  
  const lines = text.split('\n').filter(l => l.trim().length > 3);
  let name = lines[0] || "Candidate Name";

  return {
    name,
    email: emailMatch ? emailMatch[0] : "",
    phone: phoneMatch ? phoneMatch[0] : "",
    linkedin: linkedinMatch ? linkedinMatch[0] : "",
    summary: "",
    skills: [],
    experience: [],
    projects: [], // Added fallback for projects
    education: [],
    achievements: []
  };
};

// --- 4. API Request ---
export const askAI = async (prompt) => {
  try {
    const response = await axios.post(`${API_URL}/ask`, { 
      prompt, 
      max_tokens: 3000 // Increased for safety
    });
    
    if (response.data.success) return response.data.data;
    if (response.data.result) return response.data.result;
    return null;
  } catch (error) {
    console.error("AI Connection Error:", error);
    return null;
  }
};

// --- 5. Main Parser ---
export const parseResumeWithAI = async (resumeText) => {
  const cleanText = cleanResumeText(resumeText);
  console.log("Sending to AI:", cleanText.slice(0, 100));

  const prompt = `
    You are a Data Extraction Engine. Extract resume details into strict JSON.
    
    CRITICAL RULES:
    1. **NAME**: The name is the very first 2-3 words. It is NOT "Summary".
    2. **PROJECTS**: Extract the "PROJECTS" section carefully.
       - "VitalNex" and "AI-Powered Interview System" are PROJECTS, not just text.
    3. **EDUCATION**: Split "Pune CGPA" -> "Institution: Pune, Grade: CGPA".
    4. Provide ONLY the rewritten text. 
    5. Do NOT give options (Option 1, Option 2).
    6. Do NOT include conversational filler ("Here is the improved version").
    7. Do NOT use bullet points. Write it as a single paragraph.

    Required JSON Structure:
    {
      "name": "Full Name",
      "email": "Email",
      "phone": "Phone",
      "location": "City",
      "linkedin": "Url",
      "github": "Url",
      "summary": "Summary text",
      "skills": ["Skill1", "Skill2"],
      "experience": [
        { "id": "1", "company": "Company Name", "position": "Role", "duration": "Dates", "description": "Details" }
      ],
      "projects": [
        { "id": "1", "name": "Project Name", "tech": "Technologies used", "description": "What it does" }
      ],
      "education": [
        { "id": "1", "institution": "College Name", "degree": "Degree", "year": "Year", "grade": "Score" }
      ],
      "achievements": ["Achievement 1"]
    }

    Resume Text:
    "${cleanText.slice(0, 6000)}"
  `;

  const rawOutput = await askAI(prompt);

  if (rawOutput) {
    console.log("🤖 AI Response:", rawOutput);
    const parsedData = extractJsonFromText(rawOutput);
    
    if (parsedData) {
      if (!parsedData.name || parsedData.name.toLowerCase().includes("summary")) {
        const fallback = manualFallbackParser(resumeText);
        parsedData.name = fallback.name;
      }
      return parsedData;
    }
  }

  return manualFallbackParser(resumeText);
};

export const improveResumeText = async (currentText) => {
  const prompt = `Rewrite to be professional and concise:\n"${currentText}"`;
  return await askAI(prompt);
};



// import axios from 'axios';

// const API_URL = 'http://localhost:5000/api/ai';

// // --- 1. Aggressive Text Cleaner (The Fix) ---
// // This runs BEFORE the AI to fix specific scanning errors
// const cleanResumeText = (text) => {
//   return text
//     .replace(/\r\n/g, "\n")
//     .replace(/\t/g, " ")
//     // Fix merged words: "PuneCGPA" -> "Pune CGPA"
//     .replace(/([a-z])([A-Z])/g, '$1 $2') 
//     // Fix merged numbers: "Khamgaon86" -> "Khamgaon 86"
//     .replace(/([a-zA-Z])(\d)/g, '$1 $2') 
//     // Remove headers that confuse the AI about the Name
//     .replace(/^(SUMMARY|RESUME|CURRICULUM VITAE|PROFILE)$/im, "") 
//     // Flatten whitespace
//     .replace(/\s+/g, " ")
//     .trim();
// };

// // --- 2. JSON Extractor ---
// // Hunts for the JSON object inside the AI's conversation
// const extractJsonFromText = (text) => {
//   try {
//     let clean = text.replace(/```json/g, '').replace(/```/g, '');
//     const firstBrace = clean.indexOf('{');
//     const lastBrace = clean.lastIndexOf('}');
    
//     if (firstBrace !== -1 && lastBrace !== -1) {
//       clean = clean.substring(firstBrace, lastBrace + 1);
//     }
    
//     return JSON.parse(clean);
//   } catch (e) {
//     return null;
//   }
// };

// // --- 3. Manual Fallback (Safety Net) ---
// // If AI fails, this Regex parser takes over so you never get empty data
// const manualFallbackParser = (text) => {
//   console.warn("⚠️ AI Failed. Using Manual Regex Fallback.");
  
//   const emailMatch = text.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/);
//   const phoneMatch = text.match(/(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/);
//   const linkedinMatch = text.match(/linkedin\.com\/in\/[a-zA-Z0-9-]+/);
  
//   // Name Logic: Take the first non-empty line that isn't a link or email
//   const lines = text.split('\n').filter(l => l.trim().length > 3);
//   let name = "Candidate Name";
//   for(let line of lines) {
//     if(!line.includes('@') && !line.includes('http') && !line.toLowerCase().includes('resume')) {
//       name = line.trim();
//       break;
//     }
//   }

//   return {
//     name: name,
//     email: emailMatch ? emailMatch[0] : "",
//     phone: phoneMatch ? phoneMatch[0] : "",
//     linkedin: linkedinMatch ? linkedinMatch[0] : "",
//     github: "",
//     summary: "",
//     skills: [],
//     experience: [],
//     education: [],
//     achievements: []
//   };
// };

// // --- 4. Main AI Request ---
// export const askAI = async (prompt) => {
//   try {
//     const response = await axios.post(`${API_URL}/ask`, { 
//       prompt, 
//       max_tokens: 2500 // Ensure we have enough tokens for the full JSON
//     });
    
//     if (response.data.success) return response.data.data;
//     if (response.data.result) return response.data.result;
//     return null;
//   } catch (error) {
//     console.error("AI Connection Error:", error);
//     return null;
//   }
// };

// // --- 5. The Parser Function ---
// export const parseResumeWithAI = async (resumeText) => {
//   // A. Clean the text first
//   const cleanText = cleanResumeText(resumeText);
//   console.log("Sending to AI:", cleanText.slice(0, 100) + "...");

//   const prompt = `
//     You are a Data Extraction Engine. 
//     Task: Extract resume details into a strict JSON format.
    
//     CRITICAL RULES:
//     1. **NAME**: The name is the very first 2-3 words of the text. It is NOT "Summary".
//     2. **EDUCATION**: Extract ALL education entries (B.Tech, Diploma, School). 
//        - If you see "Pune CGPA", split it into "City: Pune" and "Grade: CGPA".
//        - If you see "Khamgaon 86%", split it into "City: Khamgaon" and "Grade: 86%".
//     3. **OUTPUT**: Return ONLY the JSON object. No Markdown. No text.

//     Required JSON Structure:
//     {
//       "name": "Full Name",
//       "email": "Email",
//       "phone": "Phone",
//       "location": "City, Country",
//       "linkedin": "LinkedIn URL",
//       "github": "GitHub URL",
//       "summary": "Professional Summary",
//       "skills": ["Skill1", "Skill2", "Skill3"],
//       "experience": [
//         { "id": "1", "company": "Name", "position": "Role", "duration": "Dates", "description": "Details" }
//       ],
//       "education": [
//         { "id": "1", "institution": "College Name", "degree": "Degree", "year": "Year", "grade": "Score" }
//       ],
//       "achievements": ["Achievement 1"]
//     }

//     Resume Text:
//     "${cleanText.slice(0, 5500)}"
//   `;

//   // B. Try AI Extraction
//   const rawOutput = await askAI(prompt);

//   if (rawOutput) {
//     const parsedData = extractJsonFromText(rawOutput);
    
//     // C. Validation: If AI missed the name, override it manually
//     if (parsedData) {
//       if (!parsedData.name || parsedData.name.toLowerCase().includes("summary")) {
//         console.log("Fixing Name...");
//         const fallback = manualFallbackParser(resumeText);
//         parsedData.name = fallback.name;
//       }
//       return parsedData;
//     }
//   }

//   // D. Fallback if AI fails completely
//   return manualFallbackParser(resumeText);
// };

// export const improveResumeText = async (currentText) => {
//   const prompt = `Rewrite to be professional and concise:\n"${currentText}"`;
//   return await askAI(prompt);
// };